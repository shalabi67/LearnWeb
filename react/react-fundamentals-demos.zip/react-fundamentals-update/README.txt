React Fundamentals Exercise Files
=================================

For these demos to work you will need to:

1. Open the root directory of the demo in a terminal. This is usually where the `package.json` file is. E.g. 02\demos\demo-1-click-counter\click-counter

2. With node.js and npm already installed, run `npm install`. This will install all of the required dependencies. 

NOTE: previous versions of this archive bundled all dependencies so that `npm install` was not required. The dependencies have been removed to make the archive smaller and easier to deal with. 



