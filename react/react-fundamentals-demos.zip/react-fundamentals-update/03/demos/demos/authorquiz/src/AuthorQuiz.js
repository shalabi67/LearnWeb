import React, { Component } from 'react';
import './App.css';
import './bootstrap.min.css';

class AuthorQuiz extends Component {
  render() {
    return (
      <div>Author Quiz</div>
    );
  }
}

export default AuthorQuiz;
